$(document).ready(function(){
	$('div.tooltip').hide();

	
	$('#formpost').submit(function(event){
		event.preventDefault();
		form_data = JSON.stringify($(this).serializeArray());
		console.log(form_data);
		fd = new FormData();
		if ($('#fileupload')[0].files[0]){
		fd.append("fileupload", $('#fileupload')[0].files[0]);
		}
		$.each($.parseJSON(form_data), function(index, value){
			fd.append(value["name"], value["value"]);
		});
		$.ajax({
		       url: "/postcontent",
		       type: "POST",
		       data: fd,
		       processData: false,
		       contentType: false,
		       success: function(response) {
		           $('#pre_post').replaceWith("<div id='pre_post'></div>"+response);
		           $('#formpost').find('input').val('');
		           $('#formpost').find('textarea').val('');
		       },
		       error: function(jqXHR, textStatus, errorMessage) {
		           console.log(errorMessage); // Optional
		       }
		    });

	});
});

$(document).on("click",".alike", function(event){
		event.preventDefault();
		post_id = $(this).parent().parent().parent().parent().attr("id")
		type = $(this).attr("type");
		if(type == "like"){
			url = "/likepost"
			txt = "Unlike"
			typeset = "unlike"
		}
		else{
			url = "/unlikepost"
			txt = "Like"
			typeset = "like"
		}
		that = this;
		$.ajax({
		       url: url,
		       type: "GET",
		       data: {"post_id" : post_id},
		       success: function(response) {
		           $(that).text(response+txt);
		           $(that).attr("type", typeset);
		       }
		    });
	});

$(document).on("click",'#linkupload', function(event){
		event.preventDefault();
		$('#fileupload').toggle();
	});

	$(document).on("click",'.acomment',function(event){
		event.preventDefault();
		console.log($(this).parent().parent().attr('class'));
		$(this).parent().parent().siblings('.divcomment').toggle();								
	});
$(document).on("submit", ".formcomment", function(event){
	event.preventDefault();
	comment = $(this).children().find(".txtcomment").val();
	post_id = $(this).children().find(".txtcomment").attr("post_id");
	$.ajax({
		       url: "/comment",
		       type: "GET",
		       data: {"post_id" : post_id, "comment" : comment},
		       success: function(response) {
		           console.log(response);
		       }
		    });
});